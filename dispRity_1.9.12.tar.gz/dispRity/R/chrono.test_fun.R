## note that changepoint is TIME BEFORE PRESENT (i.e Ma geological time)


## sanitizing function for changepoint + time.window
# check.time <- function(object, class, msg, type, tree) {
#     match_call <- match.call()

#     # class_object <- class(object)[1]
#     # length_class <- length(class)
#     if (type == "changepoint"){

#         if (is(object, "numeric") || is(object, "integer") ) {
#             tree_span <- c(max(node.depth.edgelength(tree)), min(node.depth.edgelength(tree)))
#             if(!object < tree_span[1] && object > tree_span[2]) {
#                 stop.call(match_call$object, " changepoint is either larger or smaller than the tree span...\n")
#             }
#         }
#         return(set.changepoint(object))
#         if (is(object, "character") && !object == "detect"){
#             stop.call(match_call$object, " must be `detect` if character string or a numeric value...\n")
#         }
#     }

#     if (type == "time.window") {
#         if (object == 1){
#             stop.call(match_call$object, " must be either vector of times, a numeric >1 or =<0.5...\n")
#         }
#     }
# }
make.deltatronic.list <- function(changepoint, data, dimension.level, n.matrix) {
    changepoint <- as.numeric(changepoint)
    
    disp_vals <- get.disparity(data, concatenate = FALSE)
    numeric_time <- as.numeric(names(disp_vals))
    
    n_matrices <- max(1, as.numeric(n.matrix))
    
    delta_df <- lapply(seq_len(n_matrices), function(i) {
        
        if (n_matrices == 1) {
            disp_mat <- t(as.data.frame(disp_vals, check.names = FALSE))
            
        } else if (dimension.level == 1) {
            temp_list <- do.call(rbind, disp_vals)
            disp_mat <- matrix(temp_list[, i], ncol = 1, dimnames = list(rownames(temp_list), NULL))
            
        } else {
            extracted <- lapply(disp_vals, function(x) x[, i])
            disp_mat <- t(as.data.frame(extracted, check.names = FALSE))
        }
        
        time_mat   <- as.matrix(numeric_time)
        impact_mat <- as.matrix(as.numeric(numeric_time <= changepoint))
        
        res <- list(
            time         = time_mat,
            time_elapsed = as.matrix(max(numeric_time) - numeric_time),
            impact       = impact_mat,
            disparity    = as.matrix(disp_mat)
        )
        
        res$time_post_cp <- as.matrix(ifelse(res$impact == 0, 0, changepoint - res$time))
        
        return(res)
    })
    
    return(delta_df)
}


make.deltatronic <- function(data, changepoint, time.window, dimension.level, n.matrix) {

    match_call <- match.call()

    # if (n.matrix) {
    #     multi_dis <- replicate(length(data$matrix), list(data))
    # }

    if (identical(changepoint,"detect")) {
        changepoint <- as.list((names(data$subsets)))
        names(changepoint)  <- names(data$subsets)
        changepoint[[length(changepoint)]] <- NULL
        changepoint[[1]] <- NULL
    }  #@@@  check if still works even if changepoint is not an actual datapoint - should do


    if (!is(changepoint, "list") && is.numeric(changepoint)){
        changepoint  <- set.changepoint(changepoint)
    }

    delta_df <- lapply(changepoint, make.deltatronic.list, data = data, dimension.level, n.matrix)


    if(!is.null(time.window)) {
            delta_df <- lapply(delta_df, lapply, set.time.window, time.window)
    }
    return(delta_df)
}


make.ctrl.deltatronic <- function(data, changepoint, time.window, dimension.level, nsim) {

    match_call <- match.call()

    # if (n.matrix) {
    #     multi_dis <- replicate(length(data$matrix), list(data))
    # }

    if (identical(changepoint,"detect")) {
        changepoint <- as.list((names(data$subsets)))
        names(changepoint)  <- names(data$subsets)
        changepoint[[length(changepoint)]] <- NULL
        changepoint[[1]] <- NULL
    }  #@@@  check if still works even if changepoint is not an actual datapoint - should do


    if (!is(changepoint, "list") && is.numeric(changepoint)){
        changepoint  <- set.changepoint(changepoint)
    }

    ctrl_delta_df <- Map(function(cp, control_list) {
        lapply(control_list, function(cont){
            make.deltatronic.list(cp, cont, dimension.level, nsim)
        })
    }, changepoint, data)

    if(!is.null(time.window)) {
            ctrl_delta_df <- lapply(ctrl_delta_df, lapply, lapply, set.time.window, time.window)
    }
    return(ctrl_delta_df)
}


set.time.window <- function(delta_df, time.window) { ## @@@ decide what the minimum number of points can be; start with 2 either side, and what if changepoint is on a datapoint

    match_call <- match.call()
    if(is(time.window, "numeric") && length(time.window) == 1 && time.window > 1) { ## choose n = time.time.window datapoints either side
        data_pre_impact <- lapply(delta_df, function(x) x[delta_df$impact == 0, , drop = FALSE])
        data_post_impact <- lapply(delta_df, function(x) x[delta_df$impact == 1, , drop = FALSE])
        kept_data_pre <- lapply(data_pre_impact, function(x) x[(length(data_pre_impact$time)-(time.window - 1)):length(data_pre_impact$time), , drop = FALSE])
        kept_data_post <- lapply(data_post_impact, function(x) x[1:time.window, , drop = FALSE]) 
        kept_data <- Map(rbind,kept_data_pre,kept_data_post)
    }

    if(is(time.window,"numeric") && length(time.window) == 2) { ## time window around changepoint. note that this time should be going from past to present in Ma style time
        pre_time <- max(time.window)
        post_time  <- min(time.window)
        kept_data_pre <- lapply(delta_df, function(x) x[delta_df$time <= pre_time & delta_df$impact == 0, , drop = FALSE])
        kept_data_post <- lapply(delta_df, function(x) x[delta_df$time >= post_time & delta_df$impact == 1, , drop = FALSE])
        kept_data <- Map(rbind,kept_data_pre,kept_data_post)
    }

    if(is(time.window, "numeric") && length(time.window) ==1 && time.window <= 0.5) { ## calculates percentage of data to keep either side of impact
        data_pre_impact <- lapply(delta_df, function(x) x[delta_df$impact == 0, , drop = FALSE])
        data_post_impact <- lapply(delta_df, function(x) x[delta_df$impact == 1, ,drop = FALSE])
        rows_to_keep_pre <- ceiling((length(data_pre_impact$time) * (time.window*2)))
        rows_to_keep_post <- ceiling(length(data_post_impact$time) * (time.window*2))
        kept_data_pre <- lapply(data_pre_impact, function (x) x[(nrow(x)-(rows_to_keep_pre - 1)):nrow(x), , drop = FALSE])
        kept_data_post <- lapply(data_post_impact, function (x)x[1:rows_to_keep_post, , drop = FALSE])
        kept_data <- Map(rbind,kept_data_pre,kept_data_post)
    }

    if (sum(kept_data$impact == 0) < 2 || sum(kept_data$impact == 1) < 2) {
        stop.call(match_call$time.window, " window is too small. Needs at least 2 datapoints either side of the impact to run the function...\n")
    }

    return(kept_data)
}

set.changepoint  <- function(changepoint){
    if (is(changepoint, "numeric") || is(changepoint, "integer")){
        changepoint <- as.list(changepoint)
        names(changepoint) <- changepoint
        return(changepoint)
    } else if(changepoint == "detect"){
        ## do something here for detect
        return(changepoint)
    }
}


average.method <- function(delta_df, test = stats::t.test, dimension.level,  ...) {
    # if (!c("disparity", "impact") %in% names(delta_df)){
    #     stop()
    # }

    if(dimension.level == 1){
        t <- test(delta_df$disparity ~ delta_df$impact, ...)
    } else if(dimension.level > 1 ){
        ## need a multivariate test, eg permanova? or t.test across each axis
        # do permanova here
        t <- list()
        for (i in 1:dimension.level){
            t[[i]] <- test(delta_df$disparity[, i] ~ delta_df$impact)
        }
    }
    return(t)
}






itsa.method <- function(delta_df,  dimension.level, ...) {

    # if(itsa.type) ##@@@ allow gls to be used with autocorrelation

    # if (dimension.level > 1){ 
        
    # }

    itsa_dat <- list(
        disparity    = delta_df$disparity, #@@@ might be multi column
        time_elapsed = as.numeric(delta_df$time_elapsed),
        impact       = as.numeric(delta_df$impact),
        time_post_cp = as.numeric(delta_df$time_post_cp)
    )

    if (dimension.level > 1){  ## if a multidimensional dispRity.metric for loop over each axis
        model <- list()
        delta_df$counter_mean_ci <- matrix(NA, nrow = nrow(itsa_dat$disparity), ncol = ncol(itsa_dat$disparity))
        delta_df$counter_lower_ci <- matrix(NA, nrow = nrow(itsa_dat$disparity), ncol = ncol(itsa_dat$disparity))
        delta_df$counter_upper_ci <- matrix(NA, nrow = nrow(itsa_dat$disparity), ncol = ncol(itsa_dat$disparity))

        counterfactual_df <- data.frame(
                        time_elapsed = itsa_dat$time_elapsed,
                        impact       = 0,
                        time_post_cp = 0
            )

        for (i in 1:dimension.level){
            model[[i]] <- lm(disparity[, i] ~ time_elapsed + impact + time_post_cp, data = itsa_dat)
            counterfactual_predicts <- predict(model[[i]], newdata = counterfactual_df, interval = "confidence")
            delta_df$counter_mean_ci[, i] <- as.matrix(counterfactual_predicts[, "fit"])
            delta_df$counter_lower_ci[,i] <- as.matrix(counterfactual_predicts[, "lwr"])
            delta_df$counter_upper_ci[,i] <- as.matrix(counterfactual_predicts[, "upr"])
        }
    } else {

        model <- lm(disparity ~ time_elapsed + impact + time_post_cp, data = itsa_dat, ...)

        counterfactual_df <- data.frame(
                    time_elapsed = itsa_dat$time_elapsed,
                    impact       = 0,
                    time_post_cp = 0
        )
        
        counterfactual_predicts <- predict(model, newdata = counterfactual_df, interval = "confidence")

        delta_df$counter_mean_ci  <- as.matrix(counterfactual_predicts[, "fit"])
        delta_df$counter_lower_ci <- as.matrix(counterfactual_predicts[, "lwr"])
        delta_df$counter_upper_ci <- as.matrix(counterfactual_predicts[, "upr"])

    }

    return(list(
        data = delta_df,
        model = model
    ))
}


# calculate.angular.effect <- function(itsa) {

#     # if (citsa){



#     # }    

#     model <- itsa$model
#     delta_df <- itsa$data

#     m1_emp <- coef(model)["time_elapsed"] ## basline slope
#     m_diff <- coef(model)["time_post_cp"] ## change in slope

#     m2 <- m1 + m_diff ## post-impact slope

#     sd_time <- sd(delta_df$time_elapsed, na.rm = TRUE) ## stdev of time
#     sd_disp <- sd(delta_df$disparity, na.rm = TRUE) ## stdev of disparity across **whole curve** (think that is right)

#     if (is.na(sd_disp) || sd_disp == 0 || is.na(sd_time) || sd_time == 0) {
#     return(NA)
#     }

#     beta1 <- m1 * (sd_time / sd_disp) ## standardise by stdev of time and stdev of disparity
#     beta2 <- m2 * (sd_time / sd_disp)


#     ## note that using atan() is non-linear, therefore it is harder to get a large effect size if the baseline angle is already steep, than if the baseline was narrow.
#     theta1 <- atan(m1) * (180 / pi) ## convert to geometric angles from radians
#     theta2 <- atan(m2) * (180 / pi) ## same here
#     angular_effect_size <- (theta2 - theta1) / 180

# ## Area if disparity before K-Pg is constant  (=slope of LM before is not signif)
# slope = 2
# x_axes_time <- 13
# y_axes_disparity <- slope*x_axes_time
# surface_triangle <- x_axes_time * y_axes_disparity / 2 
# relative_surface <- surface_triangle/ x_axes_time^2
# relative_surface

# ## Area if disparity before K-Pg is not constant (increase of decrease)
# relative_surface <- surface_triangle/ (surface_triangle+x_axes_time^2)
# relative_surface

#     return(list(
#     baseline_angle_deg = theta1,
#     post_impact__angle_deg   = theta2,
#     angle_delta_deg    = theta2 - theta1,
#     effect_size   = angular_effect_size
#     ))
# }


area.method <- function(itsa) {
    
    data <- itsa$data
    
    post_intervention_dat <- lapply(data, function(x)  x[data$impact == 1, ,drop =FALSE])

    ## extracts amount of disparity that falls outside of CI envelope, otherwise put as 0
    exceed_upper <- pmax(post_intervention_dat$disparity - post_intervention_dat$counter_upper_ci, 0) 
    exceed_lower <- pmax(post_intervention_dat$counter_lower_ci - post_intervention_dat$disparity, 0)

    time_intervals <- diff(post_intervention_dat$time_elapsed)

    area_above <- sum(((exceed_upper[-length(exceed_upper)] + exceed_upper[-1]) / 2) * time_intervals, na.rm = TRUE)
    area_below <- sum(((exceed_lower[-length(exceed_lower)] + exceed_lower[-1]) / 2) * time_intervals, na.rm = TRUE)

    return(c(area_above = area_above, area_below = area_below))
}



paint.branches <- function(tree, changepoint) {

    if(is.null(tree$root.time)) {
        root_age <- (set.root.time(tree))$root.time
    } else {
        root_age <- tree$root.time
    }
    
    node_ages <- root_age - ape::node.depth.edgelength(tree)

    N_edges <- nrow(tree$edge)
    mapped_edge <- matrix(0, nrow = N_edges, ncol = 2)
    colnames(mapped_edge) <- c("pre_impact", "post_impact")
    rownames(mapped_edge) <- paste(tree$edge[,1], tree$edge[,2], sep=",")
    
    maps <- list()
    
    for(i in 1:N_edges) {
        parent_node <- tree$edge[i, 1]
        child_node  <- tree$edge[i, 2]
        
        age_parent <- node_ages[parent_node]
        age_child  <- node_ages[child_node]
        
        if(age_child >= changepoint) {
            mapped_edge[i, "pre_impact"] <- tree$edge.length[i]
            maps[[i]] <- c("pre_impact" = tree$edge.length[i])
        }
        else if(age_parent <= changepoint) {
            mapped_edge[i, "post_impact"] <- tree$edge.length[i]
            maps[[i]] <- c("post_impact" = tree$edge.length[i])
        }
        else {
            pre_time <- age_parent - changepoint
            post_time <- changepoint - age_child
            
            mapped_edge[i, "pre_impact"] <- pre_time
            mapped_edge[i, "post_impact"] <- post_time
            
            maps[[i]] <- c("pre_impact" = pre_time,
                           "post_impact" = post_time)
        }
    }
    
    tree$mapped.edge <- mapped_edge
    tree$maps <- maps
    class(tree) <- c("simmap", "phylo")
    
    return(tree)
}


make.control <- function(changepoint, data, nsim = 100, paint = TRUE, slice.model = NULL, n.matrix, ...) { ## change slice.model name for clarity

    if (paint) {
        slice.model  <- NULL
    }

    if (!paint && is.null(slice.model)){
        stop("`slice.model` argument needs to be inputted if paint = FALSE...\n")
    }

    if (!paint && !is.null(slice.model)) {
        all_models <- c("acctran", "deltran", "random", "proximity", "equal.split", "gradual.split")
        check.length(slice.model, 1, paste(" argument must be one of the following: ", paste(all_models, collapse = ", "), ".", sep = ""))
        check.method(slice.model, all_models, "slice.model argument")
    }

    metric <- get.metric.from.call(data, 2) ## store for later
    slices <- as.numeric(names(data$subsets)) # store for later
    slice_call <- data$call$subsets
    tree <- get.tree(data)
    mat <- list()
    for(i in 1:n.matrix){
        mat[[i]] <- get.matrix(data, matrix = i)
    }










    ## if matrix is single matrix (simple version)
    # simulate.control(mat, changepoint, data, nsim, paint, slice.model)
        # else
    ##  if matrices is multi.ace output (same tip data across all matrices (come up with function to detect))
        # simulate.control(mat[[1]], changepoint,...)
    ## if matrices is all different
        # work out how many sims per matrix to make nsims?
        # n_sim  <- nsim / n_matrices
        # simulate.control(sample(matrice, replace = FALSE) ...)
    ## also add toggle that takes nodes or only tips to avoid contamination.

        


    ###@@@ need logic that can detect if its a `multi.ace` output, then it just iterates across them. if the matrices are all different (i.e. due ot intraspecific variation) then it does one per matrix.

    simulate.control <- function(mat, changepoint, nsim, paint, slice.model) {
        sim_parameters <- replicate(ncol(mat), list(root_value = NULL, sig_sq = NULL), simplify = FALSE) ## create empty list structure for storing trait parameters

        if (paint) {

            painted_tree <- paint.branches(tree, changepoint)
            n <- length(tree$tip.label)
            tip_mat <- mat[tree$tip.label, , drop = FALSE]
            painted_tree <- paint.branches(tree, changepoint)

            for(i in 1:ncol(mat)) {
                fit_bm <- mvMORPH::mvBM(tree = painted_tree, data = tip_mat[, i], model = "BMM", echo = FALSE, diagnostic = FALSE)
                sim_parameters[[i]]$sig_sq <- fit_bm$sigma[, , "pre_impact"] * n / (n - 1)   ## REML correction, see Revell http://www.phytools.org/***SanJuan2016/ex/5/Fitting-BM.html.
                sim_parameters[[i]]$root_value <- as.numeric(fit_bm$theta)
            }

        } else { ## use tree slicing

            if (slice.model == "proximity" || slice.model == "acctran" || slice.model == "deltran") {
                pre_tree <- slice.tree(tree, age = changepoint, model = slice.model, keep.all.ancestors = TRUE)
                pre_mat <- mat[pre_tree$tip.label, ] ## can just prune the matrix as it is if using punctuated model
            }

            if (slice.model == "gradual.split" || slice.model == "equal.split") {
                pre_tree <- slice.tree(tree, age = changepoint, model = "acctran", keep.all.ancestors = TRUE)
                slice_vals <- slice.tree(tree, age = changepoint, model = slice.model, keep.all.ancestors = TRUE)
                pre_mat <- matrix(NA, nrow = length(pre_tree$tip.label), ncol = ncol(mat))
                rownames(pre_mat) <- as.character(slice_vals[, 2])
                for (i in seq_along(pre_tree$tip.label)) {
                    if(slice_vals[i, 3] == "0"){
                        pre_mat[i, ] <- mat[slice_vals[i, 2], ]
                    } else {
                        t0 <- mat[slice_vals[i, 1], ]
                        t1 <- mat[slice_vals[i, 2], ]
                        slice_position <- as.numeric(slice_vals[i, 3]) ## get slice position across branch
                        pre_mat[i, ] <- (slice_position * t0) + ((1-slice_position) * t1) ## weighted average
                    }
                }
            }
            n <- length(pre_tree$tip.label)
            for(i in 1:ncol(pre_mat)) {
                fit_bm <- mvMORPH::mvBM(tree = pre_tree, data = pre_mat[, i], model = "BM1", echo = FALSE, diagnostic = FALSE) ## taken out error, can put back in
                n <- length(pre_tree$tip.label)
                sim_parameters[[i]]$sig_sq <- fit_bm$sigma * n / (n - 1)  ## REML correction, see Revell http://www.phytools.org/***SanJuan2016/ex/5/Fitting-BM.html.
                sim_parameters[[i]]$root_value <- as.numeric(fit_bm$theta)
            }
        }

        ## TODO use slice.tree and gradual.split. use get.tree for the tree in each subset.

        control_traits <- lapply(sim_parameters, function(axis) {
            root_value <- axis$root_value
            sig_sq <- axis$sig_sq
            treats::make.traits(process = treats::BM.process, start = root_value, n = 1, process.args = list(Sigma = sig_sq))
        })
        mapped_control <- replicate(nsim, {do.call(cbind, lapply(lapply(control_traits, treats::map.traits, tree = tree), function(x){x$data}))}, simplify = FALSE) ## produces however many differnt BM simulations as controls


        chrono <- chrono.subsets(mapped_control, tree, method = slice_call[1], model = slice_call[2], bind.data = as.logical(slice_call["bind"]), inc.nodes = TRUE, time = slices) ## slices using the slice call from empirical data curve


        
        disp <- dispRity(chrono, metric = metric)
        # disp$disparity <- t(disp$disparity)
        disp$call$disparity$metrics <- data$call$disparity$metrics
        disp$call$disparity$metrics <- data$call$disparity$metrics ## reattach metric fun info
        disp$sim_params <- do.call(cbind, sim_parameters)
        return(disp)
    }

    ## check if all tips and tip values are same?

    # data$tree
    ## detect if it is a ancestral state sample output:
    if (length(mat) > 1 && length(unique(lapply(mat, rownames))) == 1) {
        # tree <- get.tree(data)
        tips <- tree$tip.label
        tip_mats <- lapply(mat, function(x) x[tips, ])
        if (length(unique(tip_mats)) == 1){ ## if TRUE is a multi.ace output
            mat <- list(mat[[1]]) ## you only need one matrix to estimate BM.
        }
    } 

    control <- lapply(mat, simulate.control, changepoint, nsim, paint, slice.model)

    ##@@@ if matrices is all different TODO
        # work out how many sims per matrix to make nsims?
        # n_sim  <- nsim / n_matrices
        # simulate.control(sample(matrice, replace = FALSE) ...)
    ## also add toggle that takes nodes or only tips to avoid contamination.

    return(control)

}


bind.delta <- function(delta_df, control_delta_df, dimension.level) {
    if (dimension.level > 1) {

    #@@@ needs work to sort out when is multidimensional

    # full_df <- Map(function(control_cp, delta_cp){
    #     Map(function(control_multi, delta_multi){
    #         lapply(control_multi, function(sim){
    #             # fill = TRUE allows binding with differing columns
    #             as.data.frame(rbindlist(list(sim, delta_multi), fill = TRUE))
    #         })
    #     }, control_cp, delta_cp)
    # }, control_df, delta_df_binded)
    }

    # delta_df <- lapply(delta_df, lapply, as.numeric)

    delta_df_binded <- lapply(delta_df, lapply, function(mat){


        ## normalise by dividing by mean disparity pre-intervention
    mat <-  as.data.frame(mat)
    pre_mean <- mean(mat[mat$impact == 0,]$disparity, na.rm = TRUE)
    pre_sd <- sd(mat[mat$impact == 0,]$disparity, na.rm = TRUE) ## important that NA values are removed
    mat$disparity <- (mat$disparity - pre_mean) / pre_sd

    return(mat)
    
    })



    control_df <- lapply(control_delta_df, lapply, lapply, function(mat){
        mat <- as.data.frame(mat)
        pre_mean <- mean(mat[mat$impact == 0,]$disparity, na.rm = TRUE)
        pre_sd <- sd(mat[mat$impact == 0,]$disparity, na.rm = TRUE) ## again important NA values are removed (common issue when there is not enough data to get a disp value at a time point)
        mat$disparity <- (mat$disparity - pre_mean) / pre_sd
        return(mat)
    })

    full_df <- Map(function(control_cp, delta_cp){
        Map(function(control_multi, delta_multi){
            lapply(control_multi, function(sim){
                rbind(sim, delta_multi)
            })
        }, control_cp, delta_cp)
    }, control_df, delta_df_binded)

    return(full_df)

}


###@@@ see thomas photo on how to relativise, using triangle. the coefficients are extracted, the maximum change is 1 which is a straight line upwards, everything else is a proportion of that change in angle.



citsa.method <- function(full_df){

    ## normalise the values

    # ctrl_normalising_factor <- mean(subset(full_df, emp_vs_null == 0 & impact == 0)$disparity) ## mean of pre-int dispairty
    # emp_normalising_factor <- mean(subset(full_df, emp_vs_null == 1 & impact == 0)$disparity)
    # full_df$disparity <- full_df[full_df$emp_vs_null == 0,]$disparity


        model <- tryCatch({
                lm(
                disparity ~ time_elapsed + impact + emp_vs_null + time_post_cp +
                            time_elapsed:emp_vs_null + 
                            impact:emp_vs_null + 
                            time_post_cp:emp_vs_null,
                data = full_df,
                # correlation = corAR1(form = ~ time_index | real_vs_control), ## checked and this causes more type i/ii errors
                # weights = varIdent(form = ~ 1 | real_vs_control),
                # method = "REML",
                na.action = na.omit
            )}, error = function(e){
                warning(paste0("Model failed to converge:", e$message))
                return(NULL)
        })

        ctrl_slope_change <- model$coefficients[["time_post_cp"]]
        emp_slope_change <- model$coefficients[["time_post_cp"]] + model$coefficients[["emp_vs_null:time_post_cp"]]

        return(list(model = model, control_slope_change = ctrl_slope_change, emp_slope_change = emp_slope_change, data = full_df))
}

## started function to take draws from itsa envelope but is not correct way i think
# itsa.sig <- function(itsa) {
#     lapply(itsa$test.output, lapply, function(x){
#         cf_draws_list <- matrix(nrow = nrow(x$data$counter_lower_ci), ncol = 100)
#         for (i in 1:nrow(counter_lower)) {
#             cf_draws_list[i,] <- runif(100, x$data$counter_lower_ci[i,], x$data$counter_upper_ci[i,]) ## get 100 values in between the 95%ci
#         }
#         bind <- list(disparity = cf_draws_list, time_elapsed = x$data$time_elapsed, impact = )

#         for (i in 1:ncol(cf_draws_list)) {
#             lm(cf_draws_list[,i] ~ )
#         }


#     })
# }